#ifndef COMM_H_
#define COMM_H_


#define MAX_MODULE 16
#define MODULE_CPL 0

#define FUNCTION_ID_NONE -1
#define FUNCTION_ID_MAIN 9


#endif