#include "hash_table.h"
#include "mem_pool.h"   // 操操操操操操操操， 不包含这个文件，在静态库的场景会crash
#include <stdio.h>

HASH_MAP hashmap;
bool trace_flag = false;
ULL depth = 0;
int depth_is_zero_num = 0;

void get_basic_info()
{
    if (depth == 0) {
        depth_is_zero_num++;
    }
}
    
void __attribute__((constructor)) traceBegin(void); // 这东西不太适合对C++插桩
// 因为，这个函数并不是限制性的，C++有可能是限制属性alloc，这个也是会被插桩的
// 对于C的目标文件是先执行的

// 所以为了统一起见，还是不要用这个东西了
// 可以使用全局变量，depth
// depth == 0
// 在__cyg_profile_func_enter()中表示刚开始
// 在__cyg_profile_func_exit() 表示结束

void __attribute__((destructor)) traceEnd(void);

void __cyg_profile_func_enter(void *func, void *caller);

void __cyg_profile_func_exit(void *func, void *caller);

 
// 这样的操作，就是只对constructor destructor之间的代码采样
void __attribute__((constructor, no_instrument_function)) traceBegin(void) {
    trace_flag = true;
    printf("__traceBegin__\n");
    hash_map_init(&hashmap);
}

void __attribute__((destructor, no_instrument_function)) traceEnd(void) {
    hash_map_show(&hashmap);
    hash_map_destory(&hashmap);
    trace_flag = false;
    printf("---------------------traceEnd - Basic Info-----------------------\n");
    printf("[basic info]: depth_is_zero_num: %d\n", depth_is_zero_num);
    printf("[basic info]: __traceEnd__\n");
    printf("-----------------------------------------------------------------\n");
}

void __cyg_profile_func_enter(void *func, void *caller) {
    if (trace_flag == false) return;
    get_basic_info();
    // if (depth == 0) {
    //     __traceBegin();
    // }
    // printf("depth:%lld\n",depth);
    depth++;
    // printf("__cyg_profile_func_enter\n");
    // printf("## enter %p\n", func);
    // printf("## enter %lld\n", (ULL)func);

    NODE_Ptr nodeptr = get_node(&hashmap.nodeMemPool);
    make_node(nodeptr, (ULL)func, (ULL)caller, 1, 456456, 789798);
    // show_node(nodeptr);
    hash_map_insert(&hashmap, nodeptr);
}

void __cyg_profile_func_exit(void *func, void *caller) {
    if (trace_flag == false) return;
    // printf("__cyg_profile_func_exit\n");

    NODE_Ptr nodeptr = get_node(&hashmap.nodeMemPool);
    make_node(nodeptr, (ULL)func, (ULL)caller, 1, 456456, 789798);
    // show_node(nodeptr);
    hash_map_insert(&hashmap, nodeptr);

    depth--;
    // printf("depth:%lld\n",depth);
    // if (depth == 0) {
    //     __traceEnd();
    // }
}