rm -rf ./*.o ./*.a ./*.so

gcc -shared -fPIC *.c -o libhook.so