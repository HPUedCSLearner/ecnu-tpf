g++ *.cpp -o parse
cp parse ../