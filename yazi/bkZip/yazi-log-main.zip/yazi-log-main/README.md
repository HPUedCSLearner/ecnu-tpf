# yazi-log
a tiny c++ logger
